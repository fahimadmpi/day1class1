<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>padma</title>
    <?php wp_head();?>

</head>
<body>
    <!-- header part start -->
<header class="container-fluid slider">
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <?php
      $qry = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'padma'
      ]);
      ?>
  <div class="carousel-inner">
    <?php
  $x=0;
    while($qry->have_posts()){$qry->the_post();
   $x++; 
    ?>
    <div class="carousel-item <?= ($x==1)?'active':''?> ">
        <?php the_post_thumbnail();?>
    </div>
  
    <?php } ?>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</header>
    
  <!-- header part end -->
  <!-- hero part start -->

  <section class="container hero text-center">
    <div class="row">
      <?php dynamic_sidebar('herotile')?>

    </div>
    <div class="row">

           <div class="col-sm-4">
                    <div class="card" style="width: 18rem;">
                     <?php dynamic_sidebar('herocard1');?>
                    </div>
           </div>

           <div class="col-sm-4">
           <div class="card" style="width: 18rem;">
                     <?php dynamic_sidebar('herocard2');?>
                    </div>
                </div>
          
                <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                     <?php dynamic_sidebar('herocard3');?>
                    </div></div>
      
    </div>
    </sectoin>
  <!-- hero part end -->
  <!-- photo part start -->

  <section class='container photo'>
    <div class="row">T
      <div class="col-sm-5">
        <?php dynamic_sidebar('lineleft');?>

      </div>
      <div class="col-sm-5">
        <?php dynamic_sidebar('photolitle');?>
      </div>
      <div class="col-sm-5">
        <?php dynamic_sidebar('linerright');?>
      </div>
    </div>

    <div class="row">
      <div class="card" style="width: 18rem;">
                     <?php dynamic_sidebar('photocard');?>
                    </div>

      <div class="col-sm-3">1</div>
      <div class="col-sm-3">2</div>
      <div class="col-sm-3">3</div>
      <div class="col-sm-3">4</div>

  </div>
</div>

    </div>

    </section>
  <!-- photo part end -->
  <!-- News part start -->
<section class="container news-5 mb-5 ">
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <?php
      $qry2 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'padma'
      ]);
      ?>
  <div class="carousel-inner">
    <?php
  $x=0;
    while($qry->have_posts()){$qry->the_post();
   $x++; 
    ?>
    <div class="carousel-item <?= ($x==1)?'active':''?> ">
        <?php the_title();?>
    </div>
  
    <?php } ?>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>
  <!-- News part end -->
  <!-- footer part start -->
<footer class="container-fluid">
<div class="row container">
  <div class="col-sm-6">
    <?php dynamic_sidebar('footerleft');?>
  </div>
  <div class="col -sm-6">2</div>
</div>
<div class="row container">B</div>
</footer>
  <!-- footer part end -->
 

    <?php wp_footer();?>

</body>
</html>